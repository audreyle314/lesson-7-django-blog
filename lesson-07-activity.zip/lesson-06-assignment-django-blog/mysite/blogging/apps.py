from django.apps import AppConfig


class BloggingConfig(AppConfig):
    name = 'blogging'
